# Brutal-SCW
Brutal-SCW In Python Program Spam Otp This Number Target (+62) only
